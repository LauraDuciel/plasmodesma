#!/usr/bin/env python 
# encoding: utf-8

"""Routine for making Bokeh plots 

"""

from __future__ import print_function
from spike import NPKError
from spike.NPKData import NPKData_plugin

import os
import bokeh.plotting as bk
from bokeh.models import Range1d
from bokeh.plotting import output_file, show, gridplot, figure
from bokeh.resources import CDN
from bokeh.embed import file_html, components


def makebokeh(npkd, title=None, xlabel=None, ylabel=None, zoom = None, color = 'olive', bokeh_range = None,
        path_file = "bk.html", plot_width = 500, plot_height = 500,
        show = False):
    '''
    Makes Bokeh plot. The plugin attaches a figure : bokeh_figure and a range : bokeh_range to the npkd object.
    Transmitting bokeh_range from one plot to another permits to synchronize the plots.
    By default the plugin makes locally a bk.html file. The corresponding figure can be viewed inthe browser using "show = True".
    ### 
    zoom : zoom bounds for making the html Bokeh file
    title : title of the plot
    xlabel : x axis label
    ylabel : y axis label
    color : color of the plot
    path_file : path for the html Bokeh file
    plot_width : width of the plot
    plot_height : height ofthe plot
    
    Example for plotting two synchronized plots.
    
    zoom = [200,2000]
    title = "title1"
    xlabel = "m/z"
    ylabel = ""

    f.bokeh(title, xlabel, ylabel, zoom = zoom, path_file = "bok.html", show=False)
    f1 = f.bokeh_figure
    ###
    title = "title2"
    xlabel = "m/z"
    ylabel = ""
    ff = f.copy()
    ff.bokeh(title, xlabel, ylabel,
             bokeh_range = f.bokeh_range, color="firebrick", show=False)
    f2 = ff.bokeh_figure
    pp = gridplot([[f1,f2]])                            # Bokeh plots side by side
    bk.show(pp)
    
    '''
    step = npkd.axis1.itype+1
    if zoom:
        npkd.extract(zoom)                                                            # Take a zoom area in the spectrum
    if path_file:
        output_file(path_file)                                                        # Bokeh output file      
    ylim = [0, npkd.get_buffer().max()*2]                                         # y limit for the plot
    ax = npkd.axis1.unit_axis()                                                 #  axis
    currunit = npkd.axis1.currentunit
    lim = {'m/z':{'x':ax[-1], 'y':ax[0]}}
    if bokeh_range:
        xr, yr = bokeh_range
    else:  
        xr = Range1d(start=lim[currunit]['x'], end=lim[currunit]['y'])                                      # x range for Bokeh
        yr = Range1d(start=-ylim[1]/10, end=ylim[1])                                  # y range for Bokeh
    TOOLS="resize, pan, wheel_zoom, box_zoom, reset, box_select, lasso_select"    # Tools for Bokeh
    dbk = {'tools': TOOLS,'x_range': xr, 'y_range': yr,
           'title': title, 'x_axis_label': xlabel, 'y_axis_label': ylabel,
           'plot_width' : plot_width, 'plot_height' : plot_height}              # Parameters for the plot
    bkf = bk.figure(**dbk)                                                      # Creates a new figure for original spectrum
    
    bkf.line(ax[::step], npkd.get_buffer(), line_color = color)                         # Plot
    if show:
        bk.show(bkf)                                                            # Makes the Bokeh plot
    npkd.bokeh_figure = bkf
    npkd.bokeh_range = [xr, yr]

NPKData_plugin("bokeh", makebokeh)