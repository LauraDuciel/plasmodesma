#!/usr/bin/env python 
# encoding: utf-8

"plugin for Sane and PG_Sane "

from __future__ import print_function
import unittest
import numpy as np
from numpy.fft import fft, ifft, rfft, irfft

from spike.NPKData import NPKData_plugin,  as_cpx, as_float, _base_fft,\
            _base_ifft, _base_rfft, _base_irfft
from spike.Algo.sane import sane
from spike.util.signal_tools import filtering

def sane_plugin(npkd, rank, orda=None, iterations=1, axis=0, trick=True, optk=False, ktrick=False):
    """
    Apply sane denoising to data
    rank is about 2 x number_of_expected_lines
    Manages real and complex cases.
    Handles the case of hypercomplex for denoising of 2D FTICR for example.
    
    sane algorithm. Name stands for Support Selection for Noise Elimination.
    From a data series return a denoised series denoised
    data : the series to be denoised - a (normally complex) numpy buffer
    rank : the rank of the analysis
    orda : is the order of the analysis
        internally, a Hankel matrix (M,N) is constructed, with M = orda and N = len(data)-orda+1
        if None (default) orda = (len(data)+1)/2
    iterations : the number of time the operation should be repeated
    optk : if set to True will calculate the rank giving the best recovery for an automatic estimated noise level. 
    trick : permits to enhanced the denoising by using a cleaned signal as the projective space. "Support Selection"
    ktrick : if a value is given, it permits to change the rank on the second pass.
             The idea is that for the first pass a rank large enough as to be used to compensate for the noise while
             for the second pass a lower rank can be used. 
    
    """
    if npkd.dim == 1:
        if npkd.axis1.itype == 0:   # real
            buff = as_cpx(_base_ifft(_base_rfft(npkd.buffer)))       # real case, go to analytical signal
        else:   #complex
            buff = npkd.get_buffer()                       # complex case, makes complex
        sane_result = sane( buff, rank, orda = orda, trick = trick, iterations = iterations) # performs denoising
        if npkd.axis1.itype == 0:   # real
            buff = _base_irfft(_base_fft(as_float(sane_result)))      # real case, comes back to real
            npkd.set_buffer(buff)
        else:
            npkd.buffer = as_float(sane_result)             # complex case, makes real
    elif npkd.dim == 2:
         todo = npkd.test_axis(axis)
         if todo == 2:
             for i in xrange(npkd.size1):
                 r = npkd.row(i).sane(rank=rank, orda=orda, iterations=iterations)
                 npkd.set_row(i,r)
         elif todo == 1:
             for i in xrange(npkd.size2):
                 r = npkd.col(i).sane(rank=rank, orda=orda, iterations=iterations)
                 npkd.set_col(i,r)
    elif npkd.dim == 3:
         raise Exception("not implemented yet")
    return npkd

def noise(data):
    "Simple noise evaluation "
    b = data.copy()
    for i in range(10):
        b = b[ b-b.mean()<3*b.std() ]
    return b.std()

def pg_sane(npkd, iterations=10, rank=10, axis=1, Lthresh=2.0, sampling=None, final='SANE'):
    """
    Papoulis Gershberg algorithm - stabilized with SANE
    
    This function takes FID with a partial sampling, and fills the holes with estimated values.
    The FID can then be processed normally, as it was completely acquired.
    
    iterations : the number of iterations used for the program
        pg_sane converges quite rapidely, and usually 5 to 20 iterations are suffisant.
        when the SNR is high, or for large data-sets (>8k) more iterations might be needed
    rank : a rough estimate of the number of lines present in the FT spectrum of the FID - not stringent -
    Lthresh : the multiplier for hard thresholding, usually 1.0
        lower is more efficient but requires more iteration
        higher requires less iteration but is less efficient
    sampling : if provided, the sampling index list and npkd is supposed to be zerofilled (missing values set to zero)
               if None, npkd.axis1.sampled should be True, and sampling it will be fetched via npkd.axis1.get_sampling()
    final: the final step after iterations,
           default is 'SANE': better (noise-less) data-sets, the best reconstruction quality in simulations
           'PG' to reapply PG step - produces the cleanest/more compressible data-sets
           'Reinject': the closest to acquired data
    """
    if cpx:
        directFT = fft
        idirectFT = ifft
    else:
        directFT = rfft
        idirectFT = lambda sp: irfft(sp, len(fiditer))  # check irfft() doc for the len()
    def PG(fid):
        "local version of the PG algorithm"
        b = directFT(fid)
        thresh =  Lthresh*noise(b)
        bf = np.where(abs(b)>thresh, b, 0)              # hard thresholding
        fiditer = idirectFT(bf)

    if npkd.dim == 1:
        if sampling is None:
            if not npkd.axis1.sampled :
                raise Exception("this function works only on NUS datasets")
            fiditer = npkd.copy().zf().get_buffer()         # initialize
            lsampling = npkd.axis1.get_sampling()
        else:
            fiditer = npkd.get_buffer()                     # initialize
            lsampling = sampling

        cpx = (fiditer.dtype == 'complex128')
        GoodOnes = fiditer[lsampling]
        
        RATIO = float(len(GoodOnes))/len(fiditer)
        power = np.linalg.norm(fiditer)/np.sqrt(RATIO)
        
        for i in range(iterations): # then loop
            fiditer[lsampling] = GoodOnes                            #Reinject
            fiditer = sane(fiditer, rank)                           # Apply Sane
            if i == 0: fiditer *= power/(np.linalg.norm(fiditer))   # normalize first iteration
            fiditer[lsampling] = GoodOnes                            #Reinject
            fiditer = PG(fiditer)                                   # Apply PG
            if i == 0: fiditer *= power/(np.linalg.norm(fiditer))   # normalize first iteration

        if final == 'SANE':
            fiditer = sane(fiditer, rank)
        elif final == 'PG':
            pass  # nothing special to do
        elif final == 'Reinject':
            fiditer[lsampling] = GoodOnes
        else:
            raise Exception('wrong mode for "final", choose "SANE", "PG", or "Reinject"')
        # we're done
        npkd.set_buffer(fiditer)
    elif npkd.dim == 2:
        todo = npkd.test_axis(axis)
        if todo == 2:
             for i in xrange(npkd.size1):
                 r = npkd.row(i).pg_sane(rank=rank, iterations=iterations, Lthresh=Lthresh, sampling=sampling, final=final)
                 npkd.set_row(i,r)
        elif todo == 1:
             for i in xrange(npkd.size2):
                 r = npkd.col(i).pg_sane(rank=rank, iterations=iterations, Lthresh=Lthresh, sampling=sampling, final=final)
                 npkd.set_col(i,r)
    elif npkd.dim == 3:
        raise Exception("not implemented yet")
    npkd.axes(axis).sampling = None
    return npkd
    

class sane_pgTests(unittest.TestCase):
    def test_NUS_sampling(self):
        '''
        NUS example
        removing the sampling noise 
        '''
        import matplotlib.pylab as plt

        import spike.util.signal_tools as u
        from numpy.fft import fft
        from spike.Tests import filename
        from spike.NPKData import NPKData
        samplingfile = "DATA_test/Sampling_file.list" # filename("Sampling_file.list")
        e = NPKData(dim = 1)
        e.axis1.load_sampling(samplingfile)
        size = 20000
        signal = u.SIGNAL_NOISE(lenfid=size, nbpeaks=10, amplitude=100, noise=50, shift = 7000)
        signal.fid
        echant = signal.fid[e.axis1.sampling]
#        print "echant.size ",echant.size
        f = NPKData(buffer = echant)
        f.axis1.load_sampling(samplingfile)
        h = f.copy()
        h.pg_sane()
        pgdb = u.SNR_dB(signal.fid0,h.get_buffer())
        print("PG_SANE reconstruction is %.1fdB should be greater than 19dB"%(pgdb))
        f.zf().fft().modulus().display(label = "NUS : FFT with sampling noise")
        h.fft().modulus().display(label = "NUS : processed with PG_SANE", new_fig = False, show = True)
        self.assertTrue(pgdb>19.0)


NPKData_plugin("sane", sane_plugin)
NPKData_plugin("pg_sane", pg_sane)
