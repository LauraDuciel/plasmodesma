#!/usr/bin/env python 
# encoding: utf-8

from __future__ import print_function
import matplotlib.cm as cm
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
from matplotlib.path import Path
from matplotlib.patches import PathPatch, Ellipse, Rectangle
import matplotlib.lines as mlines