import os,sys
sys.path.append('/Users/chiron/bitbuck')
import numpy as np
from time import time
import Bruker
import os.path as op
from matplotlib import pyplot as plt
import spike.File.BrukerNMR as bkn
import spike.NPKData as npkd

class BRUKER_RW(object):
    '''
    Reads Bruker files
    Takes informations 
    '''
    
    def __init__(self, addrproc):
        """
        Creates an object that hold everything, 1D or 2D
        add the the address of data the directory
        """
        self.addrproc = addrproc
        self.addr_expno = op.dirname(op.dirname(addrproc))
        self.addracqufile = Bruker.find_acqu(self.addr_expno)
        self.addracqu2file = Bruker.find_acqu2(self.addr_expno)
        print self.addrproc
        self.addrprocfile = Bruker.find_proc(self.addr_expno)
        self.addrproc2file = Bruker.find_proc2(self.addr_expno)
        print self.addrprocfile
        #####
        self.param_acq = Bruker.read_param(self.addracqufile)
        self.param_acq2 = Bruker.read_param(self.addracqu2file)
        self.param_proc = Bruker.read_param(self.addrprocfile)
        self.param_proc2 = Bruker.read_param(self.addrproc2file)
        ####
        self.digit_filt = round(Bruker.zerotime(self.param_acq))
        self.liminfrqrd = 5000
        # print "self.param_proc['TDeff'] ", self.param_proc['$TDeff']
        # print "self.param_proc['LB'] ", self.param_proc['$LB']
        # print "self.param_proc['SI'] ", self.param_proc['$SI']
        # print "self.param_acq2['$FnMODE'] ",self.param_acq2['$FnMODE']
        
    def load(self):
        '''
        Reads the data file (1D or 2D) and keeps it in self.data_1d for 1D
        in self.data_2d_2rr and self.data_2d_2ri for 2D.
        '''
        if os.path.exists(op.join(self.addr_expno,'fid')):
            self.read_1D()
        elif os.path.exists(op.join(self.addr_expno,'ser')):
            self.read_2D()

    def read_2D(self):
        '''
        Reads the 2D "fid" file and keeps it in self.data
        data taken as integers. 
        '''
        print "read 2D"
        self.data_DIM = '2d'
        print "type(self.param_acq2['$FnMODE']) ", type(self.param_acq2['$FnMODE'])
        print "self.param_acq2['$FnMODE'] ", self.param_acq2['$FnMODE']

        ####
        
        if self.param_acq2['$FnMODE'].strip() == '0': # echo anti-echo, States
            self.addr_data_2rr = op.join(self.addrproc,'2rr')
            self.addr_data_2ri = op.join(self.addrproc,'2ri')
            print "reading echo anti-echo file"
            self.data_2d_2rr = self.reorder_subm(np.fromfile(self.addr_data_2rr, 'i4'))
            self.data_2d_2ri = self.reorder_subm(np.fromfile(self.addr_data_2ri, 'i4'))
            
        if self.param_acq2['$FnMODE'].strip() == '3': 
            print "reading TPPI"
            self.addr_data_2rr = op.join(self.addrproc,'2rr')
            self.addr_data_2ir = op.join(self.addrproc,'2ir')
            self.data_2d_2rr = self.reorder_subm(np.fromfile(self.addr_data_2rr, 'i4'))
            self.data_2d_2ir = self.reorder_subm(np.fromfile(self.addr_data_2ir, 'i4'))
            
        if self.param_acq2['$FnMODE'].strip() == '1': 
            print "reading QF"
            self.addr_data_2rr = op.join(self.addrproc,'2rr')
            self.data_2d_2rr = self.reorder_subm(np.fromfile(self.addr_data_2rr, 'i4'))
        
        print "read finished"
            
        '''
        FnMODE  vertical value type  num
        QF : col0 + 1j col1 = C   1
        TPPI : R    3
        States : C   4
        EA : equiv to States.  6
        '''
        
    def prepare_mat(self):
        '''
        sub_per_dim : [nb of submatrices in t1, nb of submatrices in t2]
        self.param_proc['$SI'] : dimension 2 of the 2D data. 
        self.param_proc2['$SI'] : dimension 1 of the 2D data. 
        self.param_acq['$XDIM'] : size submatrix
        '''
        print "prepare matrix"
        #if self.param_acq['$FnMODE'] == '0':
        self.rdata = np.empty((int(self.param_proc2['$SI']), int(self.param_proc['$SI'])), dtype = 'complex128')
        # print "rdata.shape ",self.rdata.shape
        # print "int(self.param_proc['$SI']), int(self.param_proc['$XDIM']) ",int(self.param_proc['$SI']), int(self.param_proc['$XDIM'])
        self.dim_mat = (int(self.param_proc2['$SI']), int(self.param_proc['$SI']))
        self.dim_sub_mat = (int(self.param_proc2['$XDIM']),int(self.param_proc['$XDIM']))
        # print "self.dim_mat, self.dim_sub_mat ",self.dim_mat, self.dim_sub_mat 
        # print "self.dim_sub_mat[1] ",self.dim_sub_mat[1]
        zipshape = zip(self.dim_mat, self.dim_sub_mat)
        self.sub_per_dim = [int(i / j) for i, j in zipshape]
        # print "self.sub_per_dim ", self.sub_per_dim
        # print "self.dim_mat[0] ",self.dim_mat[0]
        self.long_mat = self.dim_mat[0]*self.sub_per_dim[1], self.dim_sub_mat[1]

    def reorder_bck_subm(self,data):
        """
        Reorder flat matrix back to sbmx Bruker data.
        self.sub_per_dim : [nb of submatrices in t1, nb of submatrices in t2]
        self.nsubs : total number of submatrices
        self.param_proc['$SI'] : shape of the 2D data. 
        self.param_acq['$XDIM'] : size submatrix
        """
        print "reorder matrix back"
        self.prepare_mat()
        interm = data.reshape(self.dim_mat)
        mat = []
        for sub_num, sub_idx in enumerate(np.ndindex(tuple(self.sub_per_dim))):
            zipshape = zip(sub_idx, self.dim_sub_mat)
            sub_slices = [slice(i * j, (i + 1) * j) for i, j in zipshape ]
            mat.append(list(np.ravel(interm[sub_slices])))
        data = np.array(mat).reshape(self.dim_mat)
        return data

    def reorder_subm(self, data):
        """
        Reorder sbmx binary Bruker data to flat matrix.
        self.sub_per_dim : [nb of submatrices in t1, nb of submatrices in t2]
        self.nsubs : total number of submatrices
        self.param_proc['$SI'] : shape of the 2D data. 
        self.param_acq['$XDIM'] : size submatrix
        """
        print "reorder matrix"
        self.prepare_mat()
        #longmat = int(self.param_proc['$SI']), int(self.param_proc2['$XDIM'])*self.sub_per_dim[1]
        # print "data.shape ",data.shape
        # print "longmat ",self.long_mat
        interm = data.reshape(self.long_mat)      
        mat = []
        for sub_num, sub_idx in enumerate(np.ndindex(tuple(self.sub_per_dim))):
            zipshape = zip(sub_idx, self.dim_sub_mat)
            sub_slices = [slice(i * j, (i + 1) * j) for i, j in zipshape ]
            slt2 = slice(sub_num*self.dim_sub_mat[0],(sub_num+1)*self.dim_sub_mat[0]) # dimension t1
            slt1 = slice(0,self.dim_sub_mat[1])# dimension t2
            # print "self.rdata[sub_slices].shape ",self.rdata[sub_slices].shape
            # print "interm[slt1, slt2].shape ",interm[slt1, slt2].shape
            # print "self.rdata[sub_slices].shape",self.rdata[sub_slices].shape
            self.rdata[sub_slices] = interm[slt2, slt1]
        data = self.rdata
        return data
        
            
    def write_file(self, data, filename):
        '''
        data written as integers. 
        '''
        f = open(filename, 'wb')
        if self.param_acq['$BYTORDA'] == '0': 
            f.write(data.astype('<i4').tostring()) # little endian
        else:
            f.write(data.astype('>i4').tostring()) # big endian
        f.close()
        print "rewrote ", filename
            

    def save_denoised_2d(self, big = False):
        """ 
        Write Bruker binary data to file
        big or little endianess.
        """
        if self.param_acq2['$FnMODE'] == '0':
            list_proc= ['2rr','2ri']
            for name_proc in list_proc:
                if name_proc == '2rr':
                    if os.path.exists(self.addr_data_2rr):
                        os.remove(self.addr_data_2rr)
                    self.write_file(self.data_2d_denoised_2rr, self.addr_data_2rr)
                else:
                    if os.path.exists(self.addr_data_2ri):
                        os.remove(self.addr_data_2ri)
                    self.write_file(self.data_2d_denoised_2ri, self.addr_data_2ri)
                    
        if self.param_acq2['$FnMODE'] == '3' :
            list_proc= ['2rr','2ir']
            for name_proc in list_proc:
                if name_proc == '2rr':
                    if os.path.exists(self.addr_data_2rr):
                        os.remove(self.addr_data_2rr)
                    self.write_file(self.data_2d_denoised_2rr, self.addr_data_2rr)
                else:
                    if os.path.exists(self.addr_data_2ir):
                        os.remove(self.addr_data_2ir)
                    self.write_file(self.data_2d_denoised_2ir, self.addr_data_2ir)

        if self.param_acq2['$FnMODE'] == '1':
            list_proc= ['2rr','2ii']
            for name_proc in list_proc:
                if name_proc == '2rr':
                    if os.path.exists(self.addr_data_2rr):
                        os.remove(self.addr_data_2rr)
                    self.write_file(self.data_2d_denoised_2rr, self.addr_data_2rr)
                else:
                    if os.path.exists(self.addr_data_2ii):
                        os.remove(self.addr_data_2ii)
                    self.write_file(self.data_2d_denoised_2ii, self.addr_data_2ii)

    def save(self):
        '''
        Save as proc file.
        '''
        print "in denoise"
        if self.data_DIM == '1d':
            self.save_denoised_1d()
        elif self.data_DIM == '2d':
            self.save_denoised_2d()

def denoise(data, pos, rank, offset=0):
    profile = data[:,pos]
    plt.plot(profile)
    print profile.dtype
    pr = np.abs(profile)
    pr.dtype='complex'
    dat = npkd.NPKData(buffer = pr)
    datden = dat.ifft().sane(rank).zf(2).apod_sin(maxi=0.5).fft().modulus().get_buffer()+offset
    return datden

if __name__=='__main__':
    command_line = False
    address = 'data_jresolved/7/pdata/1'
    ##########
    from itertools import chain
    brw = BRUKER_RW(address)
    brw.load()
    data = brw.data_2d_2rr
    ext = list(chain.from_iterable(zip([0,0],list(data.shape))[::-1]))
    print ext
    print data[10][10]
    print data[100][10]
    fig, ax = plt.subplots()
    vmin, vmax = map(float, [data.min(),data.max()])
    print vmin, vmax
    ax.imshow(np.abs(data), extent=ext, aspect=100, vmin=vmin, vmax=vmax/20)
    profs = [32900, 37128, 38713, 43734, 46905, 49066]
    plt.figure()
    plt.title('first profile')
    rank = 10
    for p in profs:
        plt.figure()
        plt.title(str(p))
        datden = denoise(data, p, rank)
        plt.plot(datden)
    plt.show()

