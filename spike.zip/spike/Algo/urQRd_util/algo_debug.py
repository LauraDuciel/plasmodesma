#!/usr/bin/env python 
# encoding: utf-8
from __future__ import print_function
def urqrd_debugs(urqrd):
    '''
    Debugging parameters.
    '''
